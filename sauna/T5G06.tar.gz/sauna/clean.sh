rm -rf /tmp/entrada /tmp/rejeitados /tmp/ger.* /tmp/bal.* ./gerador ./sauna
